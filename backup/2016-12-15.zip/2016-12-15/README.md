# ljcraw
craw information from linajia and analysis
